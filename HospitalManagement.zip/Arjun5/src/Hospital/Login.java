package Hospital;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.BevelBorder;
import javax.swing.border.EmptyBorder;

public class Login extends JFrame {
	int attempt = 0;
	Thread t=null;
	private JPanel contentPane;
	private JTextField textUsername;
	private JTextField txtPassword;
	private JFrame Tframe;
	protected Arjun iframe;

	public Login() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 730, 407);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JPanel panel = new JPanel();
		panel.setBounds(10, 11, 694, 75);
		panel.setBackground(SystemColor.activeCaption);
		panel.setBorder(new BevelBorder(BevelBorder.RAISED, Color.LIGHT_GRAY, null, null, null));
		contentPane.add(panel);
		panel.setLayout(null);

		JLabel lblNewLabel = new JLabel("Hospital Login ");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 28));
		lblNewLabel.setBounds(225, 11, 208, 53);
		panel.add(lblNewLabel);

		JPanel panel_1 = new JPanel();
		panel_1.setBounds(143, 97, 377, 177);
		panel_1.setBackground(SystemColor.activeCaption);
		panel_1.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		contentPane.add(panel_1);
		panel_1.setLayout(null);

		JLabel lblNewLabel_1 = new JLabel("Username");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1.setBounds(20, 44, 78, 14);
		panel_1.add(lblNewLabel_1);

		JLabel lbl = new JLabel("Password");
		lbl.setFont(new Font("Tahoma", Font.BOLD, 14));
		lbl.setBounds(20, 85, 78, 14);
		panel_1.add(lbl);

		JButton btnNewButton = new JButton("Login");
		btnNewButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				String username = textUsername.getText();
				String password = textUsername.getText();
				Arjun t = new Arjun();

				if (username.contains("one") && (password.contains("one"))) {
					t.setVisible(true);
				} else if (!(username.contains("one")) && (password.contains("one"))) {
					txtPassword.setText("");
					textUsername.setText("");

					attempt = +1;
					if (attempt == 3) {
						System.exit(0);
					}
				}
			}

			// t.setVisible(true);

		});

		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnNewButton.setBounds(20, 143, 89, 23);
		panel_1.add(btnNewButton);

		JButton btnNewButton_1 = new JButton("Cancel");
		btnNewButton_1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				txtPassword.setText(null);
				textUsername.setText(null);

			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnNewButton_1.setBounds(137, 143, 89, 23);
		panel_1.add(btnNewButton_1);

		JButton btnNewButton_2 = new JButton("Exit");
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnNewButton_2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				Tframe = new JFrame("Exit");
				if (JOptionPane.showConfirmDialog(Tframe, "confirm if  you want to exity", "billing system",
						JOptionPane.YES_NO_OPTION) == JOptionPane.YES_NO_OPTION) {
					System.exit(0);
				}
			}
		});
		btnNewButton_2.setBounds(259, 143, 89, 23);
		panel_1.add(btnNewButton_2);

		textUsername = new JTextField();
		textUsername.setBounds(128, 41, 151, 20);
		panel_1.add(textUsername);
		textUsername.setColumns(10);

		txtPassword = new JTextField();
		txtPassword.setBounds(128, 82, 151, 20);
		panel_1.add(txtPassword);
		txtPassword.setColumns(10);

		JPanel panel_2 = new JPanel();
		panel_2.setBounds(10, 285, 681, 72);
		panel_2.setBackground(SystemColor.activeCaption);
		panel_2.setBorder(new BevelBorder(BevelBorder.RAISED, new Color(255, 0, 0), new Color(255, 0, 0),
				new Color(255, 0, 0), Color.RED));
		contentPane.add(panel_2);
		panel_2.setLayout(null);
		
		JButton btnNewButton_3 = new JButton("");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				 try {
			         while (true) {

			            Calendar cal = Calendar.getInstance();
			            int hours = cal.get( Calendar.HOUR_OF_DAY );
			            if ( hours > 12 ) hours -= 12;
			            int minutes = cal.get( Calendar.MINUTE );
			            int seconds = cal.get( Calendar.SECOND );

			            SimpleDateFormat formatter = new SimpleDateFormat("hh:mm:ss");
			            Date date = cal.getTime();
			            String timeString = formatter.format( date );

			            printTime();

			            t.sleep( 1000 );  // interval given in milliseconds
			         }
			      }
			      catch (Exception e) { }
			}

			private void printTime() {
				// TODO Auto-generated method stub
				
			}
		});
		btnNewButton_3.setBounds(85, 11, 111, 50);
		panel_2.add(btnNewButton_3);
	}

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			@Override
			public void run() {
				try {
					Login frame = new Login();
					frame.setVisible(true);
				} catch (Exception e) {
				}
			}
		});

	}
}
